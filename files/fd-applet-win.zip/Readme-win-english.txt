FD Applet - Windows Quick Guide

1. Install JDK 17:

Install the Java environment (JDK 17) on your system.
If you don't have a preference, download and install the "Latest LTS Release" from
https://adoptium.net/

2. Folder Contents:
The extracted FD Applet folder contains the following:
- fd-applet.bat
- lib folder (fd-applet-fat.jar inside)
- examples folder (includes algebra examples)

3. Run FD Applet:
Double-click fd-applet.bat to launch the app.
(In detail, this file automatically performs the following processes:
Checks for updates, runs fd-applet-fat.jar, and opens http://localhost:8080/ in your browser.)

4. Exiting FD Applet:
To exit the app, close the open Command Prompt window and your browser.

5. Support:
If you have any questions or issues, use the menu Files → "Send Feedback or report issues",
or send an email to henomoto@omu.ac.jp.
