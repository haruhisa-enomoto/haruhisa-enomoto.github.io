FD Applet - Windows クイックガイド

1. JDK 17のインストール:
システムにJava環境（JDK 17）をインストールします。
特にこだわりがない場合は、
https://adoptium.net/
から「Latest LTS Release」を選んでダウンロードしてインストールしてください。

2. フォルダの内容:
解凍したFD Appletフォルダには以下のものが含まれています。
- fd-applet.bat
- libフォルダ（fd-applet-fat.jarが内部にあります）
- examplesフォルダ（多元環の例が含まれています）

3. FD Appletの実行:
fd-applet.batをダブルクリックすれば起動します。
（詳しくは、このファイルは次の処理を自動的に行います：
アップデートを確認し、fd-applet-fat.jarを実行して、ブラウザでhttp://localhost:8080/を開く）

4. FD Appletの終了方法:
アプリを閉じるには、開いているコマンドプロンプトのウィンドウとブラウザを閉じます。

5. サポート:
質問や問題がある場合は、メニューのFiles → "Send Feedback or report issues"を使用するか、
henomoto@omu.ac.jpにメールを送ってください。
